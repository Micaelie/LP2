﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume; /* globais */

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            {
                if (!double.TryParse(TxtAltura.Text, out altura) ||
                    (altura <= 0))
                {
                    MessageBox.Show("altura inválido");
                }

            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(TxtRaio.Text, out raio) ||
                (raio <= 0))
            {
                MessageBox.Show("raio inválido");
                TxtRaio.Focus();
            }
            else if (!double.TryParse(TxtAltura.Text, out altura) ||
                    (altura <= 0))
            {
                MessageBox.Show("altura inválido");
                TxtAltura.Focus();
            }
           
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) *
                    altura;
                TxtVolume.Text =volume.ToString("N2");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            TxtRaio.Text = "";
            TxtAltura.Text = String.Empty;
            TxtVolume.Clear();
        }

        private void TxtVolume_Validated(object sender, EventArgs e)
        {
            {
                if (!double.TryParse(TxtVolume.Text, out volume) ||
                    (volume <= 0))
                {
                    MessageBox.Show("volume inválido");
                }

            }
        }

   

        private void TxtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TxtRaio.Text, out raio) ||
                (raio <= 0))
            {
                MessageBox.Show("raio inválido");
            }
             
        }
    }
}

